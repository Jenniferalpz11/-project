# Dogs&Cats
#### Video Demo: <https://www.youtube.com/watch?v=YAXmRfrcOVc>
#### Description:My final project is a website that allow the user register donation of pets and get donation from the others people (adopt). The user can also delete your register, see your registers and selected donations to adopt a pet from de other people

All information about users, cases and selected cases for each people are stored in dogscats.db.

I used sqlalchemy extension for connect the database to application and sqlite3 to manager her.